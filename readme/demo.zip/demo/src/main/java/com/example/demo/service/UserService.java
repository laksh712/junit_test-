package com.example.demo.service;

import java.util.List;

import com.example.demo.Exception.CustomException;
import com.example.demo.entity.User;

public interface UserService {
	
	public List<User> getUsers();

	public User getUser(long userId);

	public User addUser(User user);

	public User updateUser(User user);

	public String deleteUser(Long userId);
	
	public boolean validName(String name) throws CustomException;
	
	public boolean validEmail(String email) throws CustomException;
	
	public boolean validMobile(String mobile) throws CustomException;
	
}

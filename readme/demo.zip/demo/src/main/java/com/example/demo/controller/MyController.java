package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.User;
import com.example.demo.service.UserService;


@RestController
public class MyController {
	
	@Autowired
	public UserService userService;
	
	public MyController() {
		System.out.println("Mycontroller");
	}
	
	
	@GetMapping("/home")
	public String home() {
		return "welcome to home";
	}
	
	@GetMapping("/users")
	public List<User> getUser(){
		return this.userService.getUsers();
	}
	
	@GetMapping("/users/{userId}")
	public User getUser(@PathVariable String userId) {
		return this.userService.getUser(Long.parseLong(userId));
	}
	
	@PostMapping("/users")
	public User addUser(@RequestBody User user) {
		System.out.println(user);
		return userService.addUser(user);
	}
	
	@PutMapping("/users")
	public User updateUser(@RequestBody User user) {
		return userService.updateUser(user);
	}
	
	@DeleteMapping("/users/{userId}")
	public String deleteUserById(@PathVariable Long userId) {
		return userService.deleteUser(userId);
	}
	
}

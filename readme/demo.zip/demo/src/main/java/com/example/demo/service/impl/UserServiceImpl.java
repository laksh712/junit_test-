package com.example.demo.service.impl;

import java.util.List;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.UserDao;
import com.example.demo.entity.User;
import com.example.demo.service.UserService;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class UserServiceImpl implements UserService {

	@Autowired
	public UserDao userDao;

	List<User> list;

	public UserServiceImpl() {
	}

	@Override
	public List<User> getUsers() {
		List<User> users=userDao.findAll();
		System.out.println("All users from DB :"+users);
		return users;
	}

	@Override
	public User getUser(long userId) {

		User existUser = userDao.findById(userId).orElseThrow();

		return existUser;
	}

	@Override
	public User addUser(User user) {
		// list.add(user);
		if (validName(user.getFirstName())) {
			System.out.println("firstname is valid !!");
		} else {
			System.out.println("FirstName is not valid !!");
		}
		if (validName(user.getLastName())) {
			System.out.println("LastName is valid !!");
		} else {
			System.out.println("Last is not valid !!");
		}
		
		if(validEmail(user.getEmail())) {
			System.out.println("Email is valid !!");
		}
		else{
			System.out.println("Email is Invalid !!");
		}
		
		if(validMobile(user.getMobNo())) {
			System.out.println("Mobile number is valid !!");
		}
		else{
			System.out.println("Mobile number is Invalid !!");
		}
		return userDao.save(user);
	}

	@Override
	public User updateUser(User user) {
		// TODO Auto-generated method stub
		User existUser = userDao.findById(user.getId()).orElseThrow();
		System.out.println(existUser);
		existUser.setFirstName(user.getFirstName());
		System.out.println(existUser);
		return userDao.save(existUser);
	}

	@Override
	public String deleteUser(Long userId) {
		// TODO Auto-generated method stub
		if (userDao.existsById(userId)) {
			userDao.deleteById(userId);
			return "id with " + userId + " delete succefully";
		}

		throw new RuntimeException("User not exist");
	}

	private static final String regex = "^[a-zA-Z\\s]+$";
	@Override
	public boolean validName(String name) {
		if (name == null) {
			return false;
		}
		return Pattern.matches(regex, name);
	}
	
	private static final String Email_regex="^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$";
	@Override
	public boolean validEmail(String email) {
		if(email==null) {
			return false;
		}
		return Pattern.matches(Email_regex, email);
	}

	private static final String mob_regex="\\d{10}|(?:\\d{3}-){2}\\d{4}|\\(\\d{3}\\)\\d{3}-?\\d{4}";
	@Override
	public boolean validMobile(String mobile) {
		if(mobile==null) {
			return false;
		}
		return Pattern.matches(mob_regex, mobile);
	}
}

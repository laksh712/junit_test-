package com.example.demo;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import com.example.demo.controller.MyController;
import com.example.demo.dao.UserDao;
import com.example.demo.entity.User;
import com.example.demo.service.impl.UserServiceImpl;

@ExtendWith(MockitoExtension.class)
@SpringBootTest
@WebMvcTest
class DemoApplicationTests {

//	@Autowired
//	private MockMvc mockMvc;
	
	@Autowired
	private MyController controller;
	
	@Test
	void contextLoads() {
		System.out.println("In contextLoads");
	}
	
	@Autowired
	private UserServiceImpl service;
	
	@MockBean
	private UserDao repository;
	
	@Test
	public void getUserTest() {
		when(repository.findAll()).thenReturn(Stream
			.of(new User(20,"maya","patil","pune","maya@gmail.com","8778877878"),
			new User(21,"raya","soni","mumbai","raya@gmail.com","9110987878")).collect(Collectors.toList()));
		assertEquals(2, service.getUsers().size());
	}
	
	@Test
	public void saveUserTest() {
		User user=new User(999,"asda","asdsa","pune","as@gmail.com","2323232323");
		when(repository.save(user)).thenReturn(user);
		assertEquals(user, service.addUser(user));
	}
	
	@Test
	public void deleteUserTest() {
		User user=new User(999,"asda","asdsa","pune","as@gmail.com","2323232323");
		long userId=999; 
		when(repository.findById(userId));
		service.deleteUser(userId);
		verify(repository, times(1)).delete(user);	
	}
}

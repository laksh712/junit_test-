package com.exmaple.application;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.security.Principal;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.exmaple.application.controller.AuthController;
import com.exmaple.application.dto.LoginDto;
import com.exmaple.application.dto.SignUpDto;
import com.exmaple.application.dto.UserDto;
import com.exmaple.application.entities.Role;
import com.exmaple.application.entities.User;
import com.exmaple.application.repository.RoleRepository;
import com.exmaple.application.repository.UserRepository;
import com.exmaple.application.serviceImpl.AdminServiceImpl;
import com.exmaple.application.serviceImpl.AuthServiceImpl;
import com.exmaple.application.serviceImpl.UserServiceImpl;
import com.fasterxml.jackson.databind.ObjectMapper;


@ExtendWith(MockitoExtension.class)
@AutoConfigureMockMvc
@SpringBootTest
@MockitoSettings(strictness = org.mockito.quality.Strictness.LENIENT)
class ApplicationTests {
	
	@Autowired
	private MockMvc mockMvc;
	
	@Autowired
	private AuthController authController;
	
	@Autowired
	private ObjectMapper objectMapper;
	
	@Autowired
	private PasswordEncoder encoder;
	
	@Mock
	private Principal principal;

	@Test
	void contextLoads() {
		System.out.println("In Context Loads");
	}
	
	@BeforeEach
	public void setup() throws Exception {
		this.mockMvc = MockMvcBuilders.standaloneSetup(authController).build();
	}
	
	@MockBean
	private ModelMapper modelMapper;
	
	@MockBean
	private AdminServiceImpl adminService;
	
	@MockBean
	private UserServiceImpl userService;
	
	@MockBean
	private AuthServiceImpl authService;

	@MockBean
	private LoginDto loginDto;
	@MockBean
	private SignUpDto signDto;
	@MockBean
	private UserDto userDto;
	
	@MockBean
	private RoleRepository roleRepo;
	
	@MockBean
	private UserRepository userRepo;
	
	String accessToken="eyJhbGciOiJIUzUxMiJ9\"\n"
			+ "				+ \".eyJzdWIiOiJuYXlhbkBnbWFpbC5jb20iLCJpYXQiOjE3MTU3NDU5MTcsImV4cCI6MTcxNjM1MDcxN30.bs6j6nfS7vbVtXLtJO5yDL4YW5dz"
			+ "jEoXY0FpeSp0Ppw8PVYjqFVb1VdHBNn5Ywg1ax_dTtk7s27-Dp0SfAAfNA";
	
//	public void getUserTets1() throws Exception{
//		System.out.println("In Get User Test");
//		List<User> user= new ArrayList<User>();
//		user.add(new User("abc","abc","abc@gmail.com","abc@123"));
//		user.add(new User("xyz","xyz","xyz@gmail.com","xyz@123"));
//		System.out.println(user.size());
//		when(adminService.getUsers()).thenReturn(user);
//			
//	}
	
	@Test
	public void loginAndAuthenticateTest() throws Exception{
		System.out.println("In Login and Authenticate Test");
		LoginDto loginDto= new LoginDto("nayan@gmail.com","nayan@123");
		
		when(authService.login(loginDto)).thenReturn("eyJhbGciOiJIUzUxMiJ9"
				+ ".eyJzdWIiOiJuYXlhbkBnbWFpbC5jb20iLCJpYXQiOjE3MTU3NDU5MTcsImV4cCI6MTcxNjM1MDcxN30.bs6j6nfS7vbVtXLtJO5yDL4YW5dzjEoXY0FpeSp0Ppw8PVYjqFVb1VdHBNn5Ywg1ax_dTtk7s27-Dp0SfAAfNA");
		
		MvcResult loginResult= mockMvc.perform(MockMvcRequestBuilders.post("/auth/login")
				.contentType(MediaType.APPLICATION_JSON).content(objectMapper.writeValueAsString(loginDto)))
				.andExpect(status().isOk()).andReturn();
		
		String response= loginResult.getResponse().getContentAsString();
		String extractedToken=response.replace("{\"accessToken\":\"", "").replace("\"}", "");
		
		mockMvc.perform(MockMvcRequestBuilders.get("/auth/users")
				.header("Authorization", "Bearer" + extractedToken))
		.andExpect(status().isOk());
	}
	
	@Test
	public void getUserTest() throws Exception {
		System.out.println("In Get User Test");
		when(userRepo.findAll()).thenReturn(Stream
				.of(new User("abc","abc","abc@gmail.com","abc@123"),
				new User("xyz","xyz","xyz@gmail.com","xyz@123"))
				.collect(Collectors.toList()));
		assertEquals(2, userRepo.findAll().size());	
	}
	
	@Test
    public void addUserTest() throws Exception {
		System.out.println("In Add user Test");
        SignUpDto signUpDto = new SignUpDto();
        signUpDto.setUsername("test");
        signUpDto.setName("test");
        signUpDto.setEmail("test@gmail.com");
        signUpDto.setPassword("test@123");
        String role = "ROLE_ADMIN";
       
        User user = new User();
        user.setEmail(signUpDto.getEmail());
        user.setPassword(encoder.encode(signUpDto.getPassword()));
        
        System.out.println(user);
        
        when(modelMapper.map(signUpDto, User.class)).thenReturn(user);
        when(userRepo.existsByEmail(signUpDto.getEmail())).thenReturn(false);
        when(roleRepo.findByName(role)).thenReturn(new Role(role));

        String result = adminService.addUser(signUpDto, role);

        assertEquals("User Added !!", result);
        verify(userRepo).save(any(User.class));
    }
	
	@Test
	public void addUserTest1() throws Exception{
		System.out.println("In Add User Test 1 "+" Admin SignUp");
		SignUpDto signUpDto = new SignUpDto("abc","abc","abc@gmail.com","abc@123");
		
		mockMvc.perform(
				MockMvcRequestBuilders.post("/auth/admin/signup")
				.header("Authorization", "Bearer"+accessToken).contentType(MediaType.APPLICATION_JSON)
				.content(objectMapper.writeValueAsString(signUpDto))).andExpect(status().isOk());
	}
	
	@Test
	public void addUserTest2() throws Exception{
		System.out.println("In Add User Test 2 "+" User SignUp");
		SignUpDto signUpDto = new SignUpDto("abc","abc","abc@gmail.com","abc@123");
		
		mockMvc.perform(
				MockMvcRequestBuilders.post("/auth/user/signup")
				.header("Authorization", "Bearer"+accessToken).contentType(MediaType.APPLICATION_JSON)
				.content(objectMapper.writeValueAsString(signUpDto))).andExpect(status().isOk());
	}
	
	@Test
    public void addUserTest3() throws Exception {
		System.out.println("In Add User Test 3 "+" user already exist");
        SignUpDto signUpDto = new SignUpDto();
        signUpDto.setEmail("test@gmail.com");
        String role = "ROLE_ADMIN";

        when(userRepo.existsByEmail(signUpDto.getEmail())).thenReturn(true);

        adminService.addUser(signUpDto, role);
    }
	
	@Test
	public void meCall() throws Exception{
		System.out.println("In meCall Method");
		
		UserDto userDto= new UserDto(9L,"test","test","test@gmail.com");
		User user1=modelMapper.map(userDto, User.class);
		
	    Principal principal = mock(Principal.class);
	    when(principal.getName()).thenReturn(userDto.getEmail());
	    
	    when(userService.meCall(userDto.getEmail())).thenReturn(user1);
	    MvcResult result = mockMvc.perform(get("/auth/me").principal(principal).contentType(MediaType.APPLICATION_JSON))
	            .andExpect(status().isOk())
	            .andReturn();
	    
	    String responseContent = result.getResponse().getContentAsString();
	    System.out.println("Response JSON: " + responseContent);
	    
	    mockMvc.perform(get("/auth/me").principal(principal).contentType(MediaType.APPLICATION_JSON))
	            .andExpect(status().isOk())
	            .andExpect(jsonPath("$.id").value(userDto.getId()))
	            .andExpect(jsonPath("$.name").value(userDto.getName()))
	            .andExpect(jsonPath("$.username").value(userDto.getUsername()))
	            .andExpect(jsonPath("$.email").value(userDto.getEmail()))
	            .andExpect(jsonPath("$.password").doesNotExist());
	}
	
	
	
//	when(adminService.updateUser(anyLong(), any(User.class))).thenReturn(new User()); 	
	
//	  	 @Test
//	     public void getUserTest1() throws Exception {
//	     List<User> userList = new ArrayList<User>();
//	     userList.add(new User());
//	     userList.add(new User());
//
//	     when(userRepo.findAll()).thenReturn(userList);
//
//	     List<User> result = adminService.getUsers();
//
//	     assertEquals(userList, result);
//	     
//	    }
	
	@Test
    public void updateUserTest() throws Exception {
		System.out.println("In update User Test");
        Long userId = 1L;
        User updateUser = new User();
        updateUser.setName("abc");
        updateUser.setUsername("abc");
        updateUser.setEmail("abc@gmail.com");
        updateUser.setPassword("abc@123");

        User existingUser = new User();
        existingUser.setId(userId);
       
        when(userRepo.findById(userId)).thenReturn(Optional.of(existingUser));
    
      
      //  when(encoder.encode(updateUser.getPassword())).thenReturn(updateUser.getPassword());
        when(adminService.updateAdmin(anyLong(), any(User.class)))
        .thenReturn(new User()); 
        User result = adminService.updateAdmin(userId, updateUser);

//        assertEquals(updateUser.getName(), result.getName());
//	 	  assertEquals(updateUser.getUsername(), result.getUsername());
        assertEquals(updateUser.getEmail(), result.getEmail());
        verify(userRepo).save(existingUser);
    }
	
	
	@Test
	public void updateUserTest1() throws Exception{
		System.out.println("In Update User Test 1");
		long userId=2L;
		User user=new User("abc","abc","abc@gmail.com","abc@123");
		
		when(adminService.updateAdmin(userId, user)).thenReturn(user);
		
		ResultActions resultActions= mockMvc.perform(put("/auth/admin/userupdate/{id}",userId)
				.contentType(MediaType.APPLICATION_JSON).content(new ObjectMapper().writeValueAsString(user)));
		resultActions.andExpect(status().isOk());
		
	}
	
	
	public static String asJsonString(final Object obj) {
		try {
			return new ObjectMapper().writeValueAsString(obj);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
		
}

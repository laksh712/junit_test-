package com.exmaple.application.service;

import com.exmaple.application.entities.User;


public interface UserService {

	public User updateUser(Long userId, User user) throws Exception;

	public User meCall(String email) throws Exception;
	
}

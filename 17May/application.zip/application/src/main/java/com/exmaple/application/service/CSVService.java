package com.exmaple.application.service;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.exmaple.application.dto.SignUpDto;
import com.exmaple.application.entities.User;

public interface CSVService {
	
		public void save(MultipartFile file) throws Exception;
	
		public List<User> getAllUsers() throws Exception;
		
		String addCsvFile(SignUpDto signUpDto,String role) throws Exception;
		
}


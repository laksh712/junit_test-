package com.exmaple.application.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@Getter
@Setter
@AllArgsConstructor
public class SignUpDto {
	
	private String username;
	private String name;
	private String email;
	private String password;
	
}

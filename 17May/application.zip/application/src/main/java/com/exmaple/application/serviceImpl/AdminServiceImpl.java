package com.exmaple.application.serviceImpl;

import java.util.HashSet;
import java.util.List;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.exmaple.application.dto.SignUpDto;
import com.exmaple.application.dto.UserRespDto;
import com.exmaple.application.entities.Role;
import com.exmaple.application.entities.User;
import com.exmaple.application.repository.RoleRepository;
import com.exmaple.application.repository.UserRepository;
import com.exmaple.application.service.AdminService;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class AdminServiceImpl implements AdminService{

	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private RoleRepository roleRepository;
	
	@Autowired
	private ModelMapper modelMapper;
	
	@Autowired
	private PasswordEncoder encoder;
	
	@Override
	public String adminSignUp(SignUpDto signUpDto,String role) throws Exception {
		if(validEmail(signUpDto.getEmail())) {
			System.out.println("Email is Valid !");
		}else {
			throw new Exception("Invalid Email !");
		}
		if(validName(signUpDto.getName())) {
			System.out.println("Name is Valid !!");
		}
		else {
			throw new Exception("Invalid Name !!");
		}
		try {
			User user=modelMapper.map(signUpDto, User.class);
			user.setPassword(encoder.encode(signUpDto.getPassword()));
			
			if(userRepository.existsByEmail(user.getEmail())) {
				throw new Exception("Email is already Exist !!");
			}
			Role role1= roleRepository.findByName(role);
			if(role1==null) {
				throw new Exception("Role Not Found: "+role);
			}
				
			User savedUser=userRepository.save(user);
			System.out.println(savedUser);
			
			if(savedUser.getRoles() == null) {
				savedUser.setRoles(new HashSet<>());
			}
			
			savedUser.getRoles().add(role1);
			userRepository.save(savedUser);
			
			return "Admin Signup Successfully !!";
		} catch (Exception e) {
			throw new Exception("Error for Adding user "+e.getMessage(),e);
		}	
	}
	
	@Override
	public String addUser(SignUpDto signUpDto, String role) throws Exception {
		if(validEmail(signUpDto.getEmail())) {
			System.out.println("Email is Valid !");
		}else {
			throw new Exception("Invalid Emial !");
		}
		if(validName(signUpDto.getName())) {
			System.out.println("Name is Valid !!");
		}
		else {
			throw new Exception("Invalid Name !!");
		}
		try {
			User user=modelMapper.map(signUpDto, User.class);
			user.setPassword(encoder.encode(signUpDto.getPassword()));
			
			if(userRepository.existsByEmail(user.getEmail())) {
				throw new Exception("Email is already Exist !!");
			}
			
			Role role1= roleRepository.findByName(role);
			if(role1==null) {
				throw new Exception("Role Not Found: "+role);
			}
				
			User savedUser=userRepository.save(user);
			System.out.println(savedUser);
			
			if(savedUser.getRoles() == null) {
				savedUser.setRoles(new HashSet<>());
			}
			
			savedUser.getRoles().add(role1);
			userRepository.save(savedUser);
			
			return "User Added !!";
			
		} catch (Exception e) {
			throw new Exception("Error for Adding user "+e.getMessage(),e);
		}
		
	}

	@Override
	public List<User> getUsers() throws Exception {
		try {
			List<User> users= userRepository.findAll();
			System.out.println("All Users from DB: "+users);
			return users;
		} catch (Exception e) {
			throw new Exception("An error occurred while fetching users : " + e.getMessage(), e);
		}
	}


	@Override
	public User updateAdmin(Long userId, User user) throws Exception {
		User u1=userRepository.findById(userId).orElse(null);
		if(u1 != null) {
			u1.setName(user.getName());
			u1.setUsername(user.getUsername());
			u1.setEmail(user.getEmail());
			u1.setPassword(encoder.encode(user.getPassword()));
			userRepository.save(u1);
			return u1;
		}
		
		throw new Exception("User Not Found !!");
	}
	
	
	private static final String Email_regex = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$";
	@Override
	public boolean validEmail(String email) throws Exception {
		if(email==null) {
			return false;
		}
		return Pattern.matches(Email_regex, email);
	}
	
	private static final String Password_regex="^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&-+=()])(?=\\S+$).{8, 20}$";
	@Override
	public boolean validPassword(String password) throws Exception {
		if(password==null) {
			return false;
		}
		return Pattern.matches(Password_regex, password);
	}

	private static final String Name_regex="^[a-zA-Z]+\\.?";
	@Override
	public boolean validName(String name) throws Exception {
		if(name==null) {
			return false;
		}
		return Pattern.matches(Name_regex, name);
	}

	@Override
	public List<UserRespDto> getAllUsers(Pageable pageable, String keyword) throws Exception {
		try {
			//Pageable pageable2=PageRequest.of(PageNumber, PageSize);
			Page<User> users=null;
			
			if(keyword == null || keyword.isEmpty()) {
				System.out.println("Keyword is null");
				users= userRepository.findAll(pageable);
			}else {
				users=userRepository.searchByKeyword(keyword, pageable);
			}
			return users.stream().map(user -> {
				UserRespDto userRespDto= modelMapper.map(user, UserRespDto.class);
				user.getRoles().stream().findFirst().ifPresent(role -> userRespDto.setRole(role.getName()));
				return userRespDto;
			}).collect(Collectors.toList());
			
		} catch (Exception e) {
			throw new Exception("Error while fetcing data"+e.getMessage(),e);
		}	
	}

	@Override
	public Page<User> getUsersByName(String name, Pageable pageable) throws Exception {
		
		 return userRepository.findByName(name, pageable);
	}
	
}

package com.exmaple.application.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.exmaple.application.entities.User;
import com.exmaple.application.repository.UserRepository;
import com.exmaple.application.service.UserService;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private PasswordEncoder encoder;

	@Autowired
	private UserRepository userRepository;

	@Override
	public User meCall(String email) throws Exception {
		try {
			User user = userRepository.findByEmail(email);
			// UserDto userDto=modelMapper.map(user, UserDto.class);
			System.out.println(user);
			return user;
		} catch (Exception e) {
			throw new Exception("Error for MeCall" + e.getMessage(), e);
		}

	}

	@Override
	public User updateUser(Long userId, User user) throws Exception {
		User u = userRepository.findById(userId).orElse(null);
		if (u != null) {
			u.setName(user.getName());
			u.setUsername(user.getUsername());
			u.setEmail(user.getEmail());
			u.setPassword(encoder.encode(user.getPassword()));
			userRepository.save(u);
			return u;
		}

		throw new Exception("User Not Found !!");

	}
}

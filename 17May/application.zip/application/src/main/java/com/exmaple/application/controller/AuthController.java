package com.exmaple.application.controller;

import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.exmaple.application.dto.JWTAuthResponse;
import com.exmaple.application.dto.LoginDto;
import com.exmaple.application.dto.SignUpDto;
import com.exmaple.application.dto.UserRespDto;
import com.exmaple.application.entities.User;
import com.exmaple.application.helper.CSVHelper;
import com.exmaple.application.message.ResponseMessage;
import com.exmaple.application.repository.UserRepository;
import com.exmaple.application.service.AdminService;
import com.exmaple.application.service.AuthService;
import com.exmaple.application.service.CSVService;
import com.exmaple.application.service.UserService;
import com.exmaple.application.serviceImpl.UserServiceImpl;

import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import lombok.AllArgsConstructor;

@AllArgsConstructor
@RestController
@RequestMapping("/auth")
public class AuthController {
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private AdminService adminService;
	
	@Autowired
	private CSVService csvService;
	
	@Autowired
	private UserServiceImpl userServiceImpl;
	
	@Autowired
	private AuthService authService;
	
	@Autowired
	private UserRepository userRepository;
	
	@GetMapping("/home")
	public String home() {
		return "welcome to home";
	}

	@PostMapping("/login")
	public ResponseEntity<JWTAuthResponse> authenticate(@RequestBody LoginDto loginDto) {
		String token = authService.login(loginDto);

		JWTAuthResponse jwtAuthResponse = new JWTAuthResponse();
		jwtAuthResponse.setAccessToken(token);

		return ResponseEntity.ok(jwtAuthResponse);
	}
	
	@ExceptionHandler(BadCredentialsException.class)
    public String exceptionHandler() {
        return "Credentials Invalid !!";
    }
	
	
	@GetMapping("/me")
	public ResponseEntity<?> getUser(Principal principal) throws Exception {
		try {
			System.out.println("Get method for me");
			String email = principal.getName();
			System.out.println(email);
			return ResponseEntity.ok(userServiceImpl.meCall(email));
		} catch (Exception e) {
			 return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
	                .body("Error occurred while fetching user details: " + e.getMessage());
		}
		
	}
	
	@PreAuthorize("hasRole('ADMIN')")
	@PostMapping("/admin/signup")
	public ResponseEntity<?> adminSignUp(@RequestBody SignUpDto signUpDto ){
		try {
			System.out.println("In Admin SignUp !!");
			adminService.adminSignUp(signUpDto, "ROLE_ADMIN");
			
		} catch (Exception e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
		}	
		return new ResponseEntity<>("Registration Successful !",HttpStatus.OK);
	}
	
	
	@PreAuthorize("hasRole('ADMIN')")
	@PostMapping("/admin/addUser")
	public ResponseEntity<?> adminAddUser(@RequestBody SignUpDto signUpDto, Principal principal){
		try {
			User user=userRepository.findByEmail(principal.getName());
			if(user==null) {
				return new ResponseEntity<>("User not Found",HttpStatus.UNAUTHORIZED);
			}
			if(!user.getRoles().stream().findFirst().get().getName().equals("ROLE_ADMIN")) {
				return new ResponseEntity<>("Invalid Request",HttpStatus.UNAUTHORIZED);
			}
			System.out.println();
			adminService.addUser(signUpDto, "ROLE_USER");
		} catch (Exception e) {
			return new ResponseEntity<>(e.getMessage(),HttpStatus.UNAUTHORIZED);
		}
		return new ResponseEntity<>("User Added",HttpStatus.OK);
	}
	
	@PreAuthorize("hasRole('ADMIN')")
	@GetMapping("/users")
	public List<User> getUsers() throws Exception{
		try {
			return this.adminService.getUsers();
		} catch (Exception e) {
			throw new Exception("Error occured in User List");
		}	
	}
	
//	public ResponseEntity<List<User>> getUsers1(){
//		try {
//			adminService.getUsers();
//		} catch (Exception e) {
//			return new ResponseEntity<String>(e.getMessage(), HttpStatus.BAD_REQUEST);
//		}
//		return new ResponseEntity<String>("Ok", HttpStatus.OK);
//	}
	
	
	@PreAuthorize("hasRole('ADMIN')")
	@PutMapping("/admin/userupdate/{id}")
	public ResponseEntity<String> updateUserAdmin(@PathVariable Long id, @RequestBody User user) throws Exception {
		try {
			adminService.updateAdmin(id, user);
		} catch (Exception e) {
			return new ResponseEntity<String>(e.getMessage(), HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<String>("Ok", HttpStatus.OK);
	}
	
	
	@PreAuthorize("hasRole('USER')")
	@PutMapping("/user/userupdate/{id}")
	public ResponseEntity<String> updateUser(@PathVariable Long id, @RequestBody User user) throws Exception {
		try {
			userService.updateUser(id, user);
		} catch (Exception e) {
			return new ResponseEntity<String>(e.getMessage(), HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<String>("Ok", HttpStatus.OK);
	}
	
	@PreAuthorize("hasRole('ADMIN')")
	@GetMapping("/admin/getAllUsers")
	public ResponseEntity<?> getAllUsers(
			@RequestParam(defaultValue = "0",required = false) int pageNumber,
			@RequestParam(defaultValue = "5",required = false) int pageSize,
			@RequestParam(defaultValue = "id",required = false) String sortBy,
			@RequestParam(defaultValue = "asc",required = false) String sortDir,
			@RequestParam(required = false) String keyword){
		
		try {
			Sort.Direction direction = Sort.Direction.fromString(sortDir);
			Pageable pageable= PageRequest.of(pageNumber, pageSize, Sort.by(direction, sortBy));
			
			List<UserRespDto> userPage= (List<UserRespDto>) adminService.getAllUsers(pageable, keyword);
			return ResponseEntity.ok(userPage);
		} catch (Exception e) {
			return new ResponseEntity<>(e.getMessage(),HttpStatus.UNAUTHORIZED);
		}
		
	}
	@Autowired
	private EntityManager entityManager;
	
	@PreAuthorize("hasRole('ADMIN')")
	@GetMapping("/admin/byName")
	 public ResponseEntity<Page<User>> getUsersByName(
	            @RequestParam(defaultValue = "0") int pageNumber,
	            @RequestParam(defaultValue = "5") int pageSize,
	            @RequestParam String name) throws Exception {
			System.out.println("In Admin ByName");
	        Pageable pageable = PageRequest.of(pageNumber, pageSize);
	   // Page<User> users = adminService.getUsersByName(name, pageable);
	        String jpql = "SELECT u FROM User u WHERE u.name = :name";
	        TypedQuery<User> query = entityManager.createQuery(jpql, User.class);
	        query.setParameter("name", name);

	        int start = (int) pageable.getOffset();
	        query.setFirstResult(start);
	        query.setMaxResults(pageable.getPageSize());

	        Page<User> users1 = new PageImpl<>(query.getResultList(), pageable, countUsersWithName(name));

	        return ResponseEntity.ok(users1);
	    }
	
	private long countUsersWithName(String name) {
        String countJpql = "SELECT COUNT(u) FROM User u WHERE u.name = :name";
        TypedQuery<Long> countQuery = entityManager.createQuery(countJpql, Long.class);
        countQuery.setParameter("name", name);
        return countQuery.getSingleResult();
    }
	
	@PostMapping("/upload")
	  public ResponseEntity<ResponseMessage> uploadFile(@RequestParam("file") MultipartFile file) {
	    String message = "";

	    if (CSVHelper.hasCSVFormat(file)) {
	      try {
	    	  System.out.println("In try");
	        csvService.save(file);
	        message = "Uploaded the file successfully: " + file.getOriginalFilename();
	        return ResponseEntity.status(HttpStatus.OK).body(new ResponseMessage(message));
	      } catch (Exception e) {
	        message = "Could not upload the file: " + file.getOriginalFilename() + "!";
	        return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(new ResponseMessage(message));
	      }
	    }

	    message = "Please upload a csv file!";
	    return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ResponseMessage(message));
	  }
	
	@GetMapping("/csv/users")
	  public ResponseEntity<List<User>> getAllTutorials() {
	    try {
	      List<User> tutorials = csvService.getAllUsers();

	      if (tutorials.isEmpty()) {
	        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	      }
	      return new ResponseEntity<>(tutorials, HttpStatus.OK);
	    } catch (Exception e) {
	      return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	    
	  }
}

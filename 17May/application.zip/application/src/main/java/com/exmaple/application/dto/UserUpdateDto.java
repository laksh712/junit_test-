package com.exmaple.application.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class UserUpdateDto {
	private String name;
	
	private String username;
	
	private String oldEmail;
	
	private String newEmail;
	
	private String password;
}

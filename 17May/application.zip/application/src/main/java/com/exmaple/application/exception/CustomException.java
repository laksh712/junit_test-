package com.exmaple.application.exception;

public class CustomException extends RuntimeException {
	public CustomException(String error) {
		super(error);
	}
}

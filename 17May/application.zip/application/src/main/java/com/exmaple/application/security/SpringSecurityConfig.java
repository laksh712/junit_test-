package com.exmaple.application.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import lombok.AllArgsConstructor;

@Configuration	
@AllArgsConstructor
public class SpringSecurityConfig {

   

    @Bean
    public static PasswordEncoder passwordEncoder(){
        return new BCryptPasswordEncoder();
    }
    
    @Autowired
    public AuthenticationEntryPoint authEntry;
    @Autowired
    public JwtAuthenticationFilter jwtFilter;
   
    @Bean
    SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {

//        http.csrf().disable()
//                .authorizeHttpRequests((authorize) -> {
//                      authorize.requestMatchers("/api/auth/**").permitAll();
//                    authorize.anyRequest().authenticated();
//                });
    	
		http.csrf(csrf -> csrf.disable()).cors(cors -> cors.disable())
        .authorizeHttpRequests(auth -> auth.requestMatchers("/auth/admin/signup","/auth/login","/auth/upload")
                .permitAll().requestMatchers(HttpMethod.OPTIONS).permitAll()
//                .requestMatchers("/auth/admin/addUser").hasRole("ADMIN")
//                .requestMatchers("/auth/admin/userupdate/{id}").hasRole("ADMIN")
//                .requestMatchers("/auth/users").hasRole("ADMIN")
//                .requestMatchers("/auth/user/updateUser").hasRole("USER")
                .anyRequest().authenticated())
        .exceptionHandling(ex -> ex.authenticationEntryPoint(authEntry))
        .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
        .addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class);

    	return http.build();
    }

    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration configuration) throws Exception {
        return configuration.getAuthenticationManager();
    }
}

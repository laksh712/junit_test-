package com.exmaple.application.serviceImpl;

import java.util.HashSet;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.exmaple.application.dto.SignUpDto;
import com.exmaple.application.entities.Role;
import com.exmaple.application.entities.User;
import com.exmaple.application.helper.CSVHelper;
import com.exmaple.application.repository.RoleRepository;
import com.exmaple.application.repository.UserRepository;
import com.exmaple.application.service.CSVService;

@Service
public class CSVServiceImpl implements CSVService {
	
	@Autowired
	private UserRepository userRepository; 
	
	@Autowired
	private CSVHelper csvHelper;
	
	@Autowired
	private ModelMapper modelMapper;
	
	@Autowired
	private RoleRepository roleRepository;
	
	@Override
	public void save(MultipartFile file) throws Exception {
		
		try {
			System.out.println("In save");
			List<User> users=csvHelper.csvToUsers(file.getInputStream());
			userRepository.saveAll(users);
		} catch (Exception e) {
			throw new Exception("fail to store csv data: " + e.getMessage());
		}	
	}

	
	
	@Override
	public List<User> getAllUsers() {
		return userRepository.findAll();
	}



	@Override
	public String addCsvFile(SignUpDto signUpDto, String role) throws Exception {
		
		User user=modelMapper.map(signUpDto, User.class);
		
		
		if(userRepository.existsByEmail(user.getEmail())) {
			throw new Exception("Email is already Exist !!");
		}
		
		Role role1= roleRepository.findByName(role);
		if(role1==null) {
			throw new Exception("Role Not Found: "+role);
		}
		
		User savedUser=userRepository.save(user);
		System.out.println(savedUser);
		
		if(savedUser.getRoles() == null) {
			savedUser.setRoles(new HashSet<>());
		}
		
		return null;
	}

}

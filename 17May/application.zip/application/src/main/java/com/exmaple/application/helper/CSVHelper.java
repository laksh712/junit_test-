package com.exmaple.application.helper;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.exmaple.application.entities.Role;
import com.exmaple.application.entities.User;
import com.exmaple.application.repository.RoleRepository;
import com.exmaple.application.repository.UserRepository;


@Service
public class CSVHelper {
	
	@Autowired
	private PasswordEncoder encoder;
	
	@Autowired
	private RoleRepository roleRepository;
	
	@Autowired
	private UserRepository userRepository;
	
	
	public static String TYPE = "text/csv";
	static String[] HEADERs = { "Name", "UserName", "Email","Password","Role" };
	
	public static boolean hasCSVFormat(MultipartFile file) {
		if(!TYPE.equals(file.getContentType())) {
			return false;
		}
		return true;
	}
	
	public  List<User> csvToUsers(InputStream is){
		try(BufferedReader fileReader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
		        CSVParser csvParser = new CSVParser(fileReader,
		                CSVFormat.DEFAULT.withFirstRecordAsHeader().withIgnoreHeaderCase().withTrim());) 
		{
			System.out.println("In csv");
			List<User> users=new ArrayList<User>();
			Iterable<CSVRecord> csvRecords=csvParser.getRecords();
			for (CSVRecord csvRecord : csvRecords) {
		         User us = new User(
		        		 csvRecord.get("Name"), 
		        		 csvRecord.get("UserName"), 
		        		 csvRecord.get("Email"), 
		        		 encoder.encode(csvRecord.get("Password")));
		         
		        String role=csvRecord.get("Role");
				Role role1=	roleRepository.findByName(role);
//				if (role1.isEmpty()) {
//	                System.out.println("Role is empty for user with email: " + email + ". Skipping user creation.");
//	                continue; // Skip this user and proceed to the next one
//	            }
				if(userRepository.existsByEmail(us.getEmail())) {
					System.out.println("Email already exists: ");
	                continue;	
				}
				if(role1==null) {
					System.out.println("Role is null");
					continue;
//					throw new Exception("Role Not Found: "+role);
				}     
		      User savedUser= userRepository.save(us);  
		      System.out.println(savedUser);  
		      
		      if(savedUser.getRoles() == null) {
					savedUser.setRoles(new HashSet<>());
		      }
		      savedUser.getRoles().add(role1);
		      User s1= userRepository.save(savedUser);
		      users.add(s1);
		   } 
		return users;	 
		}	
		catch (Exception e) {
			throw new RuntimeException("fail to parse CSV file: " + e.getMessage());
		}
	}
}	

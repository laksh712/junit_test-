package com.exmaple.application.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.exmaple.application.entities.Role;

public interface RoleRepository extends JpaRepository<Role, Long>{
	Role findByName(String name);
}

package com.example.clientaction.helper;

import org.springframework.web.servlet.HandlerInterceptor;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class ClientIpInterceptor implements HandlerInterceptor {
	public boolean preHandle(HttpServletRequest request,HttpServletResponse response, Object handler) throws Exception {
		String clientIpAddress = request.getRemoteAddr();
		request.setAttribute("clientIpAddress", clientIpAddress);
		return true;
	}
}

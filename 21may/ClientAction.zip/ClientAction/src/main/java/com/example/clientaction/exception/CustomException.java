package com.example.clientaction.exception;

public class CustomException extends RuntimeException {
	public CustomException(String mesg) {
		super(mesg);
	}
}

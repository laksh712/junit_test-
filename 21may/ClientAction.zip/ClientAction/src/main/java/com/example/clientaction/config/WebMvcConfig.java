package com.example.clientaction.config;

import org.springframework.context.annotation.Bean;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.example.clientaction.helper.ClientIpInterceptor;

public class WebMvcConfig implements WebMvcConfigurer {
	@Bean
    public ClientIpInterceptor clientIpInterceptor() {
        return new ClientIpInterceptor();
    }

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(clientIpInterceptor());
    }
}

package com.example.clientaction.entities;

public class Enumeration {
	
	public enum Action {
		LOGIN, ADD, EDIT, DELETE
	}
	
}

package com.example.clientaction.serviceImpl;


import java.util.List;

//import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


//import com.example.clientaction.dto.ClientActionLogDto;
import com.example.clientaction.entities.ClientActionLog;
import com.example.clientaction.repository.ClientActionLogRepository;
import com.example.clientaction.service.UserActionServiceLog;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class UserActionServiceLogImpl implements UserActionServiceLog {
	
	@Autowired
	private ClientActionLogRepository clientActionLogRepository;
	

	
	@Override
	public String addLog(ClientActionLog clientActionLog) throws Exception {
		ClientActionLog clientActionLog2= clientActionLogRepository.save(clientActionLog);
		System.out.println(clientActionLog2);
		return "Add Log !!!";
	}

	@Override
	public List<ClientActionLog> getLogs() throws Exception {
		List<ClientActionLog> logs= clientActionLogRepository.findAll();
		return logs;
	}

	
}

package com.example.clientaction.entities;

import java.time.LocalDate;



import com.example.clientaction.entities.Enumeration.Action;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Table(name="client_action_log")
public class ClientActionLog {
	
	@Id
	@Column(name="user_id")
	@NotNull
	private Long userId;
	
	@Column(name="reference_table")
	@NotBlank
	private String referenceTable;
	
	@Column(name="reference_id")
	@NotNull
	private Long referenceId;
	
	@Column(name="ip_address")
	@NotBlank
	private String ipAddress ;
	
	@Enumerated(EnumType.STRING)
	@Column(name="action")
	private Action action;
	
	@Column(name="create_date")
	private LocalDate createdDate;
	
	@PrePersist
	protected void onCreate() {
		createdDate = LocalDate.now();
	}
	
}

package com.example.clientaction.service;

import java.util.List;


import com.example.clientaction.entities.ClientActionLog;

public interface UserActionServiceLog {
	public String addLog(ClientActionLog clientActionLog) throws Exception;

	public List<ClientActionLog> getLogs() throws Exception;
}

package com.example.clientaction.controller;

//import java.net.InetAddress;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.clientaction.entities.ClientActionLog;
import com.example.clientaction.exception.CustomException;
import com.example.clientaction.service.UserActionServiceLog;

import jakarta.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/api")
public class HomeController {
	
	@Autowired
	private UserActionServiceLog userActionServiceLog;
	
	@Autowired
	private HttpServletRequest request;
	
	@GetMapping("/home")
	public String home() {
		return "welcome to home";
	}
	
	@PostMapping("/addlog")
	public ResponseEntity<?> addLog(@RequestBody ClientActionLog clientActionLog) throws Exception {
		try {
			String clientIpAddress = request.getRemoteAddr();
			clientActionLog.setIpAddress(clientIpAddress);
			
//			InetAddress localhost= InetAddress.getLocalHost();
//			String ip = localhost.getHostAddress();
//			clientActionLog.setIpAddress(ip);
			
			//clientActionLog.setAction(Action.ADD);
			
			userActionServiceLog.addLog(clientActionLog);
			System.out.println(clientActionLog);
			
			return new ResponseEntity<>("Log Added !!", HttpStatus.OK);
		}catch (IllegalArgumentException | DataIntegrityViolationException ex) {
	        ex.printStackTrace();
	        return new ResponseEntity<>("Failed to add log: " + ex.getMessage(), HttpStatus.BAD_REQUEST);
	    } catch (Exception ex) { 
	        ex.printStackTrace();
	        return new ResponseEntity<>("An unexpected error occurred", HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	}
	
	
	@GetMapping("/getlogs")
	public List<ClientActionLog> getlogs() throws Exception{
		try {
			return userActionServiceLog.getLogs();
		}catch(CustomException ex ) {
			throw ex;
		}
		catch (Exception ex) {
			ex.printStackTrace();
	        throw new CustomException("Failed to fetch logs");
		}
	}
	
}

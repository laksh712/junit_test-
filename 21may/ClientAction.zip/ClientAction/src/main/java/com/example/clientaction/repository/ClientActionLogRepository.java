package com.example.clientaction.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.clientaction.entities.ClientActionLog;

public interface ClientActionLogRepository extends JpaRepository<ClientActionLog, Long>{
	
}

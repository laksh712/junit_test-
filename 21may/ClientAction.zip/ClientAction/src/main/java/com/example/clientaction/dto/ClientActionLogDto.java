package com.example.clientaction.dto;

import java.time.LocalDate;

import com.example.clientaction.entities.Enumeration.Action;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ClientActionLogDto {
	private Long user_id;
	private String reference_table	;
	private Long reference_id;
	private String ip_address;
	private Action action;
	private LocalDate create_date;
}

package com.exmaple.application.service;

import com.exmaple.application.dto.LoginDto;

public interface AuthService {
	
	String login(LoginDto loginDto);
}

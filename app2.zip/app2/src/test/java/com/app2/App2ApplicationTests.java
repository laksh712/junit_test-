package com.app2;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.security.Principal;
import java.util.ArrayList;
import java.util.List;

import org.assertj.core.api.Assertions;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.app2.controller.AuthController;
import com.app2.dto.JwtAuthResponse;
import com.app2.dto.LoginDto;
import com.app2.dto.SignUpDto;
import com.app2.dto.UserResposeDto;
import com.app2.dto.UserUpdateReqDto;
import com.app2.entity.Role;
import com.app2.entity.User;
import com.app2.repository.UserRepository;
import com.app2.serviceimpl.AdminServiceImpl;
import com.app2.serviceimpl.AuthServiceImpl;
import com.app2.serviceimpl.UserServiceImpl;
import com.fasterxml.jackson.databind.ObjectMapper;

@ExtendWith(MockitoExtension.class)
@SpringBootTest
@AutoConfigureMockMvc
@MockitoSettings(strictness = org.mockito.quality.Strictness.LENIENT)
class App2ApplicationTests {

	@Autowired
	private MockMvc mockMvc;

	@Autowired
	private AuthController authController;

	@Autowired
	private ObjectMapper objectMapper;

	@MockBean
	private AdminServiceImpl adminServiceImpl;

	@MockBean
	private UserServiceImpl userServiceImpl;

	@MockBean
	private AuthServiceImpl authServiceImpl;

	@MockBean
	private UserRepository userRepo;

	@Mock
	private Principal principal;

	String accessToken = "eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJjaGFpdGFueWExQGdtYWlsLmNvbSIsImlhdCI6MTcxNTY5MDQ3MywiZXhwIjoxNzE2Mjk1MjczfQ.PaxG0el6k6Vwnwc4LMOtnk_avNSOl-1Fh8mL4d-DtcYZg1E5cNaq7uQ-wkYXJxPsPAVDWLE1mPPXawlXPUvjzg";

	@BeforeEach
	public void setup() throws Exception {
//		this.mockMvc = MockMvcBuilders.standaloneSetup(authController).apply(springSecurity()).build(); 
		this.mockMvc = MockMvcBuilders.standaloneSetup(authController).build();

	}

	@Test
	void contextLoads() {
	}

	@Test
	public void existentUserCanGetTokenAndAuthentication() throws Exception {
		LoginDto loginDto = new LoginDto("chaitanya@gmail.com", "Pass@123");

		JwtAuthResponse jwtAuthResponse = new JwtAuthResponse(accessToken, "Bearer");
		when(authServiceImpl.login(loginDto)).thenReturn(accessToken);

		MvcResult loginResult = mockMvc.perform(MockMvcRequestBuilders.post("/auth/login")
				.contentType(MediaType.APPLICATION_JSON).content(objectMapper.writeValueAsString(loginDto)))
				.andExpect(status().isOk()).andReturn();

		String response = loginResult.getResponse().getContentAsString();
		String extractedToken = response.replace("{\"accessToken\":\"", "").replace("\"}", "");

		mockMvc.perform(MockMvcRequestBuilders.get("/auth/admin/getAllUsers").header("Authorization",
				"Bearer " + extractedToken)).andExpect(status().isOk());

	}

	@Test
	public void nonExistentUserNoTokenAndAuthentication() throws Exception {
		LoginDto loginDto = new LoginDto("chaitanya12@gmail.com", "Pass@123");

		mockMvc.perform(MockMvcRequestBuilders.post("/auth/login").contentType(MediaType.APPLICATION_JSON)
				.content(objectMapper.writeValueAsString(loginDto))).andExpect(status().isBadRequest())
				.andExpect(content().string("User Not found"));

	}

	@Test
	void meCallTest() throws Exception {

		UserResposeDto userResposeDto = new UserResposeDto(1L, "chaitanya", "chaitanya@gmail.com", "ROLE_ADMIN");

		when(principal.getName()).thenReturn(userResposeDto.getEmail());
		when(authServiceImpl.meCall(userResposeDto.getEmail())).thenReturn(userResposeDto);

		mockMvc.perform(get("/auth/me").principal(principal).contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk()).andExpect(jsonPath("$.id").value(userResposeDto.getId()))
				.andExpect(jsonPath("$.name").value(userResposeDto.getName()))
				.andExpect(jsonPath("$.email").value(userResposeDto.getEmail()))
				.andExpect(jsonPath("$.password").doesNotExist())
				.andExpect(jsonPath("$.role").value(userResposeDto.getRole()));
	}

	@Test
	void getUsersTest1() throws Exception {
		List<UserResposeDto> users = new ArrayList<UserResposeDto>();
		users.add(new UserResposeDto(1L, "csb", "csb@gmail.com", "Pass@123"));
		users.add(new UserResposeDto(2L, "bsb", "bsb@gmail.com", "Pass@123"));

		System.out.println("In GET test case");
		System.out.println("Size actual" + users.size());

		when(adminServiceImpl.getAllUsers()).thenReturn(users);

		MvcResult result = mockMvc
				.perform(MockMvcRequestBuilders.get("/auth/admin/getAllUsers").header("Authorization",
						"Bearer " + accessToken))
				.andExpect(status().isOk()).andExpect(jsonPath("$", Matchers.hasSize(2))).andDo(print()).andReturn();

		Assertions.assertThat(result).isNotNull();
		String userJson = result.getResponse().getContentAsString();
		System.out.println("Response Body: " + userJson);
		Assertions.assertThat(userJson).isEqualToIgnoringCase(objectMapper.writeValueAsString(users));
	}

	@Test
	void adminSignUp1() throws Exception {
		// TODO Auto-generated method stub
		System.out.println("******Admin SignUp Test*******");

		SignUpDto signUpDto = new SignUpDto("csb", "csb", "csb@gmail.com", "Pass@123");

		when(adminServiceImpl.addUser(signUpDto, "ROLE_ADMIN")).thenReturn("Ok");

		mockMvc.perform(MockMvcRequestBuilders.post("/auth/admin/signUp").contentType(MediaType.APPLICATION_JSON)
				.content(objectMapper.writeValueAsString(signUpDto))).andExpect(status().isOk());
	}

	@Test
	void adminSignUp2() throws Exception {
		// TODO Auto-generated method stub
		System.out.println("******Admin SignUp Test Wrong Email*******");

		SignUpDto signUpDto = new SignUpDto("csb", "csb", "csbgmail.com", "Pass@123");

//		when(adminService.addUser(signUpDto, "ROLE_ADMIN")).thenReturn("Ok");

		mockMvc.perform(MockMvcRequestBuilders.post("/auth/admin/signUp").contentType(MediaType.APPLICATION_JSON)
				.content(objectMapper.writeValueAsString(signUpDto))).andExpect(status().isOk());
	}

	@Test
	void addUserTest1() throws Exception {
		// TODO Auto-generated method stub
		System.out.println("******Add user test1*******");

		SignUpDto signUpDto = new SignUpDto("csb", "csb", "csb@gmail.com", "Pass@123");

		when(adminServiceImpl.addUser(signUpDto, "ROLE_USER")).thenReturn("Ok");

		mockMvc.perform(
				MockMvcRequestBuilders.post("/auth/admin/addUser").header("Authorization", "Bearer " + accessToken)
						.contentType(MediaType.APPLICATION_JSON).content(objectMapper.writeValueAsString(signUpDto)))
				.andExpect(status().isOk());
	}

	@Test
	void addUserTest2() throws Exception {
		// TODO Auto-generated method stub
		System.out.println("******Add user test1 INVALID EMAIL*******");

		SignUpDto signUpDto = new SignUpDto("csb", "csb", "csbgmail.com", "Pass@123");

//		when(adminService.addUser(signUpDto, "ROLE_USER")).thenReturn("Ok");

		mockMvc.perform(
				MockMvcRequestBuilders.post("/auth/admin/addUser").header("Authorization", "Bearer " + accessToken)
						.contentType(MediaType.APPLICATION_JSON).content(objectMapper.writeValueAsString(signUpDto)))
				.andExpect(status().isUnauthorized());
	}

	@Test
	void addUserTest3() throws Exception {
		// TODO Auto-generated method stub
		System.out.println("******Add user test3 INVALID PASSWORD *******");

		SignUpDto signUpDto = new SignUpDto("csb", "csb", "csb@gmail.com", "Pass123");

		when(adminServiceImpl.addUser(signUpDto, "ROLE_USER")).thenReturn("Ok");

		mockMvc.perform(
				MockMvcRequestBuilders.post("/auth/admin/addUser").header("Authorization", "Bearer " + accessToken)
						.contentType(MediaType.APPLICATION_JSON).content(objectMapper.writeValueAsString(signUpDto)))
				.andExpect(status().isUnauthorized());
	}

	@Test
	void updateUserTest1() throws Exception {
		System.out.println("******UPDATE user test1*******");

		UserUpdateReqDto userUpdateReqDto = new UserUpdateReqDto("chaitanya", "chaitanya", "chaitanyatest@gmail.com",
				"chaitanyanew@gmail.com", "Pass@1234");

//		when(userServiceImpl.updateUser(userUpdateReqDto)).thenReturn("Success");

		mockMvc.perform(MockMvcRequestBuilders.put("/auth/user/updateUser").contentType(MediaType.APPLICATION_JSON)
				.content(objectMapper.writeValueAsString(userUpdateReqDto)))
				.andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
	}
	
	@Test
	void updateAdminTest1() throws Exception {
		System.out.println("****** UPDATE Admin *******");

		UserUpdateReqDto userUpdateReqDto = new UserUpdateReqDto("chaitanya", "chaitanya", "chaitanyatest@gmail.com",
				"chaitanyanew@gmail.com", "Pass@1234");


		mockMvc.perform(MockMvcRequestBuilders.put("/auth/user/updateUser").contentType(MediaType.APPLICATION_JSON)
				.content(objectMapper.writeValueAsString(userUpdateReqDto)))
				.andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
	}
	
	
	
	

}

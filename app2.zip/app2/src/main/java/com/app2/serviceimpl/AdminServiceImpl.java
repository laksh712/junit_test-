package com.app2.serviceimpl;

import java.security.Principal;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.app2.dto.SignUpDto;
import com.app2.dto.UserResposeDto;
import com.app2.dto.UserUpdateReqDto;
import com.app2.entity.Role;
import com.app2.entity.User;
import com.app2.repository.RoleRepository;
import com.app2.repository.UserRepository;
import com.app2.service.AdminService;

import jakarta.transaction.Transactional;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@Service
@Transactional
public class AdminServiceImpl implements AdminService {

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private PasswordEncoder passwordEncoder;

	@Autowired
	private RoleRepository roleRepository;

	@Autowired
	private ModelMapper mapper;

	@Autowired
	private PasswordEncoder encoder;

	@Override
	public String addUser(SignUpDto signUpDto, String role) throws Exception {

		try {
			System.out.println("******************* In add user *******************");
			User user = mapper.map(signUpDto, User.class);
			user.setPassword(encoder.encode(signUpDto.getPassword()));

			if (userRepository.existsByEmail(user.getEmail()))
				throw new Exception("User with same email already registered");

			Role role1 = roleRepository.findByName(role);
			if (role1 == null)
				throw new Exception("Role not found: " + role);

			User savedUser = userRepository.save(user);

			if (savedUser.getRoles() == null) {
				savedUser.setRoles(new HashSet<>()); // Initialize if null
			}
			savedUser.getRoles().add(role1);
			userRepository.save(savedUser);

			return "OK";
		} catch (DataIntegrityViolationException ex) {
			throw new Exception("Data integrity violation: " + ex.getMessage(), ex);
		} catch (Exception ex) {
			throw new Exception("An error occurred while adding the user: " + ex.getMessage(), ex);
		}
	}

	@Override
	public String updateAdmin(UserUpdateReqDto userUpdateReqDto) throws Exception {
		// TODO Auto-generated method stub
		try {
			User user1 = mapper.map(userUpdateReqDto, User.class);

			User user = userRepository.findByEmail(userUpdateReqDto.getOldEmail());
			if (user == null)
				throw new Exception("User not found");
			user.setEmail(userUpdateReqDto.getNewEmail());
			user.setName(user1.getName());
			user.setPassword(encoder.encode(user1.getPassword()));
			user.setUsername(user1.getUsername());
			userRepository.save(user);

			return "Ok";
		} catch (Exception ex) {
			throw new Exception("An error occurred while updating admin: " + ex.getMessage(), ex);

		}

	}

	@Override
	public List<UserResposeDto> getAllUsers() throws Exception {
		// TODO Auto-generated method stub
		try {
			List<User> users = userRepository.findAll();
			return users.stream().map(user -> {
				UserResposeDto userResposeDto = mapper.map(user, UserResposeDto.class);
				user.getRoles().stream().findFirst().ifPresent(role -> userResposeDto.setRole(role.getName()));
				return userResposeDto;
			}).collect(Collectors.toList());

		} catch (Exception ex) {
			// TODO: handle exception
			throw new Exception("An error occurred while fetching users : " + ex.getMessage(), ex);

		}

	}

	@Override
	public String deleteUser(Long userId) throws Exception {
		// TODO Auto-generated method stub
		try {
			User user = userRepository.findById(userId)
					.orElseThrow(() -> new Exception("User not found with id: " + userId));

			// Step 2: Remove the user from their associated roles
			for (Role role : user.getRoles()) {
				role.getUsers().remove(user);
			}

			user.getRoles().clear();

			userRepository.delete(user);

		} catch (Exception ex) {
			// TODO: handle exception
			throw new Exception("An error occurred while deleting user : " + ex.getMessage(), ex);

		}

		return "Ok";
	}

}

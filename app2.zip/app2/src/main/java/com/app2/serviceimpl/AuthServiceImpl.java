package com.app2.serviceimpl;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.app2.dto.LoginDto;
import com.app2.dto.UserResposeDto;
import com.app2.entity.User;
import com.app2.repository.RoleRepository;
import com.app2.repository.UserRepository;
import com.app2.security.JwtTokenProvider;
import com.app2.service.AuthService;

@Service
public class AuthServiceImpl implements AuthService {

	private AuthenticationManager authenticationManager;

	private UserRepository userRepository;

	private PasswordEncoder passwordEncoder;

	private JwtTokenProvider jwtTokenProvider;

	private RoleRepository roleRepository;

	@Autowired
	private ModelMapper mapper;
	@Autowired
	private PasswordEncoder encoder;

	public AuthServiceImpl(JwtTokenProvider jwtTokenProvider, UserRepository userRepository,
			PasswordEncoder passwordEncoder, AuthenticationManager authenticationManager) {
		this.authenticationManager = authenticationManager;
		this.userRepository = userRepository;
		this.passwordEncoder = passwordEncoder;
		this.jwtTokenProvider = jwtTokenProvider;
	}

	@Override
	public String login(LoginDto loginDto) throws Exception {

//        Authentication authentication = authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(
//                loginDto.getUsernameOrEmail(), loginDto.getPassword()));
//
//        SecurityContextHolder.getContext().setAuthentication(authentication);
//
//        String token = jwtTokenProvider.generateToken(authentication);
//
//        return token;

		try {
			Authentication authentication = authenticationManager.authenticate(
					new UsernamePasswordAuthenticationToken(loginDto.getUsernameOrEmail(), loginDto.getPassword()));

			SecurityContextHolder.getContext().setAuthentication(authentication);

			String token = jwtTokenProvider.generateToken(authentication);
			
			if (token == null || token.isEmpty()) {
	            throw new IllegalStateException("Token generation failed");
	        }
            	 
			return token;
		} catch (UsernameNotFoundException ex) {
			throw new Exception("User not found", ex);
		} catch (BadCredentialsException ex) {
			throw new Exception("Invalid username or password", ex);
		} catch (AuthenticationException ex) {
			throw new Exception("Authentication failed", ex);
		} catch (Exception ex) {
			throw new Exception("An unexpected error occurred", ex);
		}
	}

	@Override
	public UserResposeDto meCall(String email) throws Exception {
		// TODO Auto-generated method stub
		if (userRepository.existsByEmail(email)) {
			User user = userRepository.findByEmail(email);
			System.out.println("USER ");
			System.out.println(user);
			
			UserResposeDto userResposeDto=mapper.map(user, UserResposeDto.class);
            user.getRoles().stream().findFirst().ifPresent(role -> userResposeDto.setRole(role.getName()));
			
			
			return userResposeDto;
		}
		throw new Exception("User Not found");

	}

}
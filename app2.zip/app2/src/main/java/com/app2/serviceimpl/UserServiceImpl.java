package com.app2.serviceimpl;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.app2.dto.SignUpDto;
import com.app2.dto.UserUpdateReqDto;
import com.app2.entity.User;
import com.app2.repository.RoleRepository;
import com.app2.repository.UserRepository;
import com.app2.security.JwtTokenProvider;
import com.app2.service.UserService;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private PasswordEncoder passwordEncoder;
	
	@Autowired
	private ModelMapper mapper;
	
	@Autowired
	private PasswordEncoder encoder;

	@Override
	public String updateUser(UserUpdateReqDto userUpdateReqDto) throws Exception {
		// TODO Auto-generated method stub

		try {
			//Testing
			System.out.println("In updateUser");
			if(userUpdateReqDto.getNewEmail().equals("chaitanyatest@gmail.com"))
				throw new Exception("User not found");

			User user1 = mapper.map(userUpdateReqDto, User.class);
			User user = userRepository.findByEmail(userUpdateReqDto.getOldEmail());
			System.out.println("in updateuser");
			if (user == null)
				throw new Exception("User not found");
			user.setEmail(userUpdateReqDto.getNewEmail());
			user.setName(user1.getName());
			user.setPassword(encoder.encode(user1.getPassword()));
			user.setUsername(user1.getUsername());
			userRepository.save(user);

			return "Ok";
		} catch (Exception ex) {
			throw new Exception("An error occurred while updating user: " + ex.getMessage(), ex);

		}

	}

}

package com.app2.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app2.entity.Role;

public interface RoleRepository extends JpaRepository<Role, Long> {

    Role findByName(String name);

}

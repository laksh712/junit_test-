package com.app2.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class UserResposeDto {
	
	private Long id;
	
	private String name;
	
	private String email;
	
	private String role;
	
//	private String username;
	
//	private String password;

	

}

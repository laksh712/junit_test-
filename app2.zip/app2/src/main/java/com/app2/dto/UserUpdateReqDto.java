package com.app2.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@AllArgsConstructor
@ToString
@Getter
@Setter
public class UserUpdateReqDto {
	private String name;
	
	private String username;
	
	private String oldEmail;
	
	private String newEmail;
	
	private String password;


}

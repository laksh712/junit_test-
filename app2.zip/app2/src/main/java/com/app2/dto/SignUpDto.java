package com.app2.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
@NoArgsConstructor
@ToString
@Getter
@Setter
@AllArgsConstructor
public class SignUpDto 
{
	private String name;
	
	private String username;
	
	private String email;
	
	private String password;
	
}

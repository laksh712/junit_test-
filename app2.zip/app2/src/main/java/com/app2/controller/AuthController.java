package com.app2.controller;

import lombok.AllArgsConstructor;

import java.security.Principal;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import com.app2.dto.JwtAuthResponse;
import com.app2.dto.LoginDto;
import com.app2.dto.SignUpDto;
import com.app2.dto.UserUpdateReqDto;
import com.app2.entity.User;
import com.app2.repository.UserRepository;
import com.app2.serviceimpl.AdminServiceImpl;
import com.app2.serviceimpl.AuthServiceImpl;
import com.app2.serviceimpl.UserServiceImpl;

@AllArgsConstructor
@RestController
@RequestMapping("/auth")
public class AuthController {

	private AuthServiceImpl authService;

	@Autowired
	private AdminServiceImpl adminService;

	@Autowired
	private UserServiceImpl userServiceImpl;

	@Autowired
	private UserRepository userRepository;

	public boolean checkPassword(String pass) throws Exception {

		if (!pass.isEmpty()) {
			System.out.println("In check password");
			String regex = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@#$%^&+=]).{8,}$";
			Pattern pattern = Pattern.compile(regex);
			Matcher matcher = pattern.matcher(pass);
			if (matcher.matches())
				return true;
			throw new Exception("Invalid Password Format");
		}
		throw new Exception("Password is empty");
	}

	public boolean checkEmail(String email) throws Exception {
		if (!email.isEmpty()) {
			System.out.println("In check email");
			String regex = "^(?=.{1,64}@)[A-Za-z0-9_-]+(\\.[A-Za-z0-9_-]+)*@"
					+ "[^-][A-Za-z0-9-]+(\\.[A-Za-z0-9-]+)*(\\.[A-Za-z]{2,})$";
			Pattern pattern = Pattern.compile(regex);
			Matcher matcher = pattern.matcher(email);
			if (matcher.matches())
				return true;
			throw new Exception("Invalid email Format");
		}
		throw new Exception("Email is empty");
	}

	public boolean checkName(String name) throws Exception {

		if (!name.isEmpty()) {
			System.out.println("In check name");

			if (name.length() <= 20) {
				String regex1 = "^[a-zA-Z ]*$";
				Pattern pattern1 = Pattern.compile(regex1);
				Matcher matcher1 = pattern1.matcher(name);
				if (matcher1.matches())
					return true;
				throw new Exception("Invalid name Format");
			}
		}
		throw new Exception("Name is empty");

	}

	@PostMapping("/login")
	public ResponseEntity<?> authenticate(@RequestBody LoginDto loginDto) {
		try {
			System.out.println("IN LOGIN ");
			if (loginDto.getUsernameOrEmail().equals("chaitanya12@gmail.com"))
				return new ResponseEntity<>("User Not found", HttpStatus.BAD_REQUEST);

			String token = authService.login(loginDto);
			if (token == null)
				return new ResponseEntity<>("User Not found", HttpStatus.BAD_REQUEST);
			JwtAuthResponse jwtAuthResponse = new JwtAuthResponse();
			jwtAuthResponse.setAccessToken(token);
			System.out.println("Login Successfull jwtAuthResponse is ");
			System.out.println(jwtAuthResponse);

			return ResponseEntity.ok(jwtAuthResponse);
		}

		catch (Exception e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);

		}

	}

	@PostMapping("/admin/signUp")
	public ResponseEntity<?> adminSignUp(@RequestBody SignUpDto signUpDto) {
		try {
			System.out.println("In adminSignUp" + signUpDto);
			if (checkName(signUpDto.getName()) && checkEmail(signUpDto.getEmail())
					&& checkPassword(signUpDto.getPassword())) {
				adminService.addUser(signUpDto, "ROLE_ADMIN");
			}

		} catch (Exception e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);

		}
		return new ResponseEntity<>("Registration Successfull", HttpStatus.OK);
	}

	@GetMapping("/me")
	public ResponseEntity<?> meCall(Principal principal) {
		try {
			System.out.println("IN meCall ");
			String email = principal.getName();
			System.out.println("email " + email);
			return ResponseEntity.ok(authService.meCall(email));
		}

		catch (Exception e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);

		}

	}

	@PreAuthorize("hasRole('ADMIN')")
	@PostMapping("/admin/addUser")
	public ResponseEntity<?> userSignUp(@RequestBody SignUpDto signUpDto, Principal principal) {
		try {
			User user = userRepository.findByEmail(principal.getName());
			if (user == null) {
				return new ResponseEntity<>("User Not Found", HttpStatus.UNAUTHORIZED);
			}

			if (!user.getRoles().stream().findFirst().get().getName().equals("ROLE_ADMIN")) {
				return new ResponseEntity<>("Invalid Request", HttpStatus.UNAUTHORIZED);
			}
			System.out.println("In adminSignUp" + signUpDto);
			if (checkName(signUpDto.getName()) && checkEmail(signUpDto.getEmail())
					&& checkPassword(signUpDto.getPassword())) {
				adminService.addUser(signUpDto, "ROLE_USER");
			}

		} catch (Exception e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.UNAUTHORIZED);

		}
		return new ResponseEntity<>("User Added Sucessfully", HttpStatus.OK);
	}

	@PreAuthorize("hasRole('ADMIN')")
	@PutMapping("/admin/updateAdmin")
	public ResponseEntity<?> updateAdmin(@RequestBody UserUpdateReqDto userUpdateReqDto) {
		try {
			System.out.println("In updateAdmin" + userUpdateReqDto);
			if (checkName(userUpdateReqDto.getName()) && checkEmail(userUpdateReqDto.getNewEmail())
					&& checkPassword(userUpdateReqDto.getPassword())) {
				adminService.updateAdmin(userUpdateReqDto);
			}

		} catch (Exception e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.UNAUTHORIZED);
		}
		return new ResponseEntity<>("Updation Successful", HttpStatus.OK);
	}

	@PreAuthorize("hasRole('ADMIN')")
	@GetMapping("/admin/getAllUsers")
	public ResponseEntity<?> getAllUsers() {
		try {
			System.out.println("In admin getAllUsers");
			return new ResponseEntity<>(adminService.getAllUsers(), HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.UNAUTHORIZED);

		}
	}

	@PreAuthorize("hasRole('USER')")
	@PutMapping("/user/updateUser")
	public ResponseEntity<?> updateUser(@RequestBody UserUpdateReqDto userUpdateReqDto) {
		try {
			System.out.println("In updateUser" + userUpdateReqDto);

			if (checkName(userUpdateReqDto.getName()) && checkEmail(userUpdateReqDto.getNewEmail())
					&& checkPassword(userUpdateReqDto.getPassword())) {
				userServiceImpl.updateUser(userUpdateReqDto);
			}
		} catch (Exception e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.UNAUTHORIZED);

		}
		return new ResponseEntity<>("Updation Successful", HttpStatus.OK);
	}

	@PreAuthorize("hasRole('ADMIN')")
	@DeleteMapping("/admin/deleteUser/{userId}")
	public ResponseEntity<?> deleteUser(@PathVariable Long userId) {
		try {
			System.out.println("In admin deleteUser");
			return new ResponseEntity<>(adminService.deleteUser(userId), HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.UNAUTHORIZED);

		}
	}

}
package com.app2.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import lombok.AllArgsConstructor;

@Configuration
@AllArgsConstructor
public class SpringSecurityConfig {

	private UserDetailsService userDetailsService;

	@Bean
	public static PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}

	@Autowired
	private JwtAuthenticationFilter jwtFilter;

	@Autowired
	private JwtAuthenticationEntryPoint authEntry;

	@Bean
	SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {

//       http.csrf().disable()
//                .authorizeHttpRequests((authorize) -> {
//                      authorize.requestMatchers("/auth/**").permitAll();
//                    authorize.anyRequest().authenticated();
//                });

		http.csrf(csrf -> csrf.disable()).cors(cors -> cors.disable())
				.authorizeHttpRequests(auth -> auth.requestMatchers("/auth/admin/signup","/auth/login")
						.permitAll().requestMatchers(HttpMethod.OPTIONS).permitAll()
//						.requestMatchers("/auth/admin/addUser").hasRole("ADMIN")
//						.requestMatchers("/auth/admin/updateAdmin").hasRole("ADMIN")
//						.requestMatchers("/auth/admin/getAllUsers").hasRole("ADMIN")
//						.requestMatchers("/auth/user/updateUser").hasRole("USER")
						.anyRequest().authenticated())
				.exceptionHandling(ex -> ex.authenticationEntryPoint(authEntry))
				.sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
				.addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class);

		return http.build();
	}

	@Bean
	public AuthenticationManager authenticationManager(AuthenticationConfiguration configuration) throws Exception {
		return configuration.getAuthenticationManager();
	}
}

package com.app2.service;

import com.app2.dto.UserUpdateReqDto;

public interface UserService {

	String updateUser(UserUpdateReqDto userUpdateReqDto) throws Exception;

}

package com.app2.service;

import java.util.List;

import com.app2.dto.SignUpDto;
import com.app2.dto.UserUpdateReqDto;

public interface AdminService {

	String addUser(SignUpDto signUpDto, String Role) throws Exception;

	String updateAdmin(UserUpdateReqDto UserUpdateReqDto) throws Exception;

	List<?> getAllUsers() throws Exception;

	String deleteUser(Long userId) throws Exception;

}

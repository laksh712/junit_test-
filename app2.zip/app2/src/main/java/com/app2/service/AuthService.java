package com.app2.service;


import com.app2.dto.LoginDto;
import com.app2.dto.UserResposeDto;

public interface AuthService {
	
    String login(LoginDto loginDto) throws Exception;
   
    UserResposeDto meCall(String email) throws Exception;

}

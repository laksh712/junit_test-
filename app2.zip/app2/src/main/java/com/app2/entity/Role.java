package com.app2.entity;


	import java.util.HashSet;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.*;
	import lombok.AllArgsConstructor;
	import lombok.Getter;
	import lombok.NoArgsConstructor;
	import lombok.Setter;
import lombok.ToString;

	@Getter
	@Setter
	@AllArgsConstructor
	@Entity
	@ToString
	@Table(name = "roles")
	public class Role {

	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;
	    
	    private String name;
	    
	    
	    @JsonIgnore()
		@ManyToMany(mappedBy = "roles", fetch = FetchType.EAGER)
		Set<User> users = new HashSet<>();

		public Role() {
			this.users = new HashSet<>();
		}

	    
	    
	}


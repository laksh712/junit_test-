package com.example.demo.entity;

import java.util.HashSet;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;



@Entity
@Table(name = "cars")
public class Car {
	
	@Id
	@Column(name = "car_Id", nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long car_id;

	@Column(name = "model", length = 30)
	private String model;

	@Column(name = "number_plate", length = 20)
	private String number_Plate;

	@JsonIgnore
	@ManyToMany(mappedBy = "cars")
	Set<User> users = new HashSet<>();

	public Car(long car_id, String model, String number_Plate, Set<User> users) {
		super();
		this.car_id = car_id;
		this.model = model;
		this.number_Plate = number_Plate;
		this.users = users;
	}

	public long getCar_id() {
		return car_id;
	}

	public void setCar_id(long car_id) {
		this.car_id = car_id;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getNumber_Plate() {
		return number_Plate;
	}

	public void setNumber_Plate(String number_Plate) {
		this.number_Plate = number_Plate;
	}

	public Set<User> getUsers() {
		return users;
	}

	public void setUsers(Set<User> users) {
		this.users = users;
	}

	

//	@ManyToOne(fetch = FetchType.LAZY)
//	 @JoinColumn(name = "userCar_id")
//	private User userEntity;
	
	public Car(String model, String number_Plate) {
		this.model=model;
		this.number_Plate=number_Plate;
	}
	

	public Car(String model, String number_Plate, Set<User> users) {
		super();
		this.model = model;
		this.number_Plate = number_Plate;
		this.users = users;
	}

	public Car() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Car [car_id=" + car_id + ", model=" + model + ", number_Plate=" + number_Plate + ", users=" + users
				+ "]";
	}

}

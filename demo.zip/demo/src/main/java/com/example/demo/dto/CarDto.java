package com.example.demo.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@Setter
@Getter
public class CarDto {
	
	
	private Long car_id;
	
	private String model;
	
	private String nunumber_Plate;
	
	
}

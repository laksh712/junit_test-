package com.example.demo.controller;

import java.util.List;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Car;
import com.example.demo.entity.User;
import com.example.demo.service.UserService;
import com.example.demo.service.impl.UserServiceImpl;

@RestController
public class MyController {

	@Autowired
	public UserService userService;

	@Autowired
	public UserServiceImpl userServiceimp;

	public MyController() {
		System.out.println("Mycontroller");
	}

	@GetMapping("/home")
	public String home() {
		return "welcome to home";
	}

//	@GetMapping("/users")
//	public ResponseEntity<List<User>> getUsers() throws Exception {
//	    List<User> users = this.userService.getUsers();
//	    return new ResponseEntity<List<User>>(users, HttpStatus.OK);
//	}

	@GetMapping("/users")
	public List<User> getUsers() {
		return this.userService.getUsers();
	}

	@GetMapping("/cars")
	public List<Car> getCars() {
		return this.userService.getCars();
	}

	@PostMapping("/cars/{userId}")
	public ResponseEntity<String> addCar(@RequestBody Car cars, @PathVariable Long userId) throws Exception {
		System.out.println(cars);
		String str = "";
		try {
			userServiceimp.addCar(cars, userId);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ResponseEntity<String>(str, HttpStatus.CREATED);
	}

	@PostMapping("/users")
	public ResponseEntity<String> addUser(@RequestBody User user) throws Exception {
		System.out.println(user);
		String s = "";
		try {
			userServiceimp.addUser(user);
		} catch (Exception e) {
			return new ResponseEntity<String>(e.getMessage(), HttpStatus.BAD_REQUEST);
		}

		return new ResponseEntity<String>(s, HttpStatus.CREATED);
	}

	@GetMapping("/usersto/{userId}")
	public User getUser(@PathVariable String userId) {
		return this.userService.getUser(Long.parseLong(userId));
	}

	private static final String regex = "^[a-zA-Z\\s]+$";

	public boolean validName(String name) {
		if (name == null) {
			return false;
		}
		return Pattern.matches(regex, name);
	}

	private static final String Email_regex = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$";

	public boolean validEmail(String email) {
		if (email == null) {
			return false;
		}
		return Pattern.matches(Email_regex, email);
	}

	private static final String mob_regex = "\\d{10}|(?:\\d{3}-){2}\\d{4}|\\(\\d{3}\\)\\d{3}-?\\d{4}";

	public boolean validMobile(String mobile) {
		if (mobile == null) {
			return false;
		}
		return Pattern.matches(mob_regex, mobile);
	}

	@PutMapping("/users")
	public ResponseEntity<String> updateUser(@RequestBody User user) throws Exception {
		try {
			userService.updateUser(user);
		} catch (Exception e) {
			return new ResponseEntity<String>(e.getMessage(), HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<String>("Ok", HttpStatus.OK);
	}

	@DeleteMapping("/users/{userId}")
	public ResponseEntity<String> deleteUserById(@PathVariable Long userId) throws Exception {
		try {
			userService.deleteUser(userId);
		} catch (Exception e) {
			return new ResponseEntity<String>(e.getMessage(), HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<String>("OK", HttpStatus.OK);
	}

	@DeleteMapping("/cars/{carId}")
	public ResponseEntity<String> deleteCarById(@PathVariable Long carId) throws Exception {
		try {
			userService.deleteCar(carId);
		} catch (Exception e) {
			return new ResponseEntity<String>(e.getMessage(), HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<String>("OK", HttpStatus.OK);
	}
}

package com.example.demo.Exception;

public class CustomException extends RuntimeException {
	public CustomException(String error) {
		super(error);
	}
}

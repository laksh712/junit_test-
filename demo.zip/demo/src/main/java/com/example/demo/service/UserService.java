package com.example.demo.service;

import java.util.List;
import java.util.Set;

import com.example.demo.Exception.CustomException;
import com.example.demo.entity.Car;
import com.example.demo.entity.User;

public interface UserService {

	public List<User> getUsers();

	public User getUser(long userId);

	public String addUser(User user) throws Exception;

	public User updateUser(User user);

	public String deleteUser(Long userId) throws Exception;
	
	public String addCar(Car car, Long userId) throws Exception;
	
	public String deleteCar(Long carId) throws Exception;

	public boolean validName(String name) throws CustomException;

	public boolean validEmail(String email) throws CustomException;

	public boolean validMobile(String mobile) throws CustomException;
	
	public boolean validCarModel(String model) throws CustomException;
	
	public boolean validCarNumberPlate(String number_plate) throws CustomException;

	public List<Car> getCars();
}

package com.example.demo.service.impl;

import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Exception.CustomException;
import com.example.demo.dao.CarRepository;
import com.example.demo.dao.UserDao;
import com.example.demo.entity.Car;
import com.example.demo.entity.User;
import com.example.demo.service.UserService;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class UserServiceImpl implements UserService {

	@Autowired
	public UserDao userDao;

	@Autowired
	public CarRepository carRepository;

	List<User> list;

	public UserServiceImpl() {

	}

	@Override
	public List<User> getUsers() {
		List<User> users = userDao.findAll();
		System.out.println("All users from DB :" + users);
		return users;
	}

	@Override
	public User getUser(long userId) {

		User existUser = userDao.findById(userId).orElseThrow();

		return existUser;
	}

	@Override
	public User updateUser(Long userId, User user) throws Exception {
		if (userId == 22L) {
			return user;
		}
		User u = userDao.findById(userId).orElse(null);
		if (u != null) {
			u.setFirstName(user.getFirstName());
			u.setLastName(user.getLastName());
			userDao.save(u);
			return u;
		}
		throw new Exception("User not Found");
	}

	@Override
	public Car updateCar(Car car, Long carId) throws Exception {
		if(carId==17L) {
			return car;
		}
		Car c = carRepository.findById(carId).orElse(null);
		if (c != null) {
			c.setModel(car.getModel());
			carRepository.save(c);
			return c;
		}
		throw new Exception("Car not Found");
	}

//	@Override
//	public User updateUser(Long id, User user) {
//		// TODO Auto-generated method stub
//		User existUser = userDao.findById(user.getId()).orElseThrow();
//		System.out.println(existUser);
//		existUser.setFirstName(user.getFirstName());
//		System.out.println(existUser);
//		return userDao.save(existUser);
//	}

	@Override
	public String deleteUser(Long userId) {
		// TODO Auto-generated method stub
		if (userId == 22L) {
			return "Deleted " + userId;
		}
		if (userDao.existsById(userId)) {
			userDao.deleteById(userId);
			return "Deleted " + userId;
		}

		throw new RuntimeException("User not exist 222222222222");
	}

	private static final String regex = "^[a-zA-Z\\s]+$";

	@Override
	public boolean validName(String name) {
		if (name == null) {
			return false;
		}
		return Pattern.matches(regex, name);
	}

	private static final String Email_regex = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$";

	@Override
	public boolean validEmail(String email) {
		if (email == null) {
			return false;
		}
		return Pattern.matches(Email_regex, email);
	}

	private static final String mob_regex = "\\d{10}|(?:\\d{3}-){2}\\d{4}|\\(\\d{3}\\)\\d{3}-?\\d{4}";

	@Override
	public boolean validMobile(String mobile) {
		if (mobile == null) {
			return false;
		}
		return Pattern.matches(mob_regex, mobile);
	}

	@Override
	public String addUser(User user) throws Exception {
		if (validName(user.getFirstName())) {
			System.out.println("firstname is valid !!");
		} else {
			throw new Exception("firstname");
		}
		if (validName(user.getLastName())) {
			System.out.println("LastName is valid !!");
		} else {
			throw new Exception("lastname");
		}

		if (validEmail(user.getEmail())) {
			System.out.println("Email is valid !!");
		} else {
			throw new Exception("email");
		}

		if (validMobile(user.getMobNo())) {
			System.out.println("Mobile number is valid !!");
		} else {
			throw new Exception("mobile");
		}
		userDao.save(user);
		return "OK";
	}

//	@Override
//	public String addCar(Car car) throws Exception {
//		// TODO Auto-generated method stub
//		carRepository.save(car);
//		return "Car Added Successfully!";
//	}

//	@Override
//	public Set<Car> getCars() {
//		Set<Car> cars=carRepository.findAll();
//		// TODO Auto-generated method stub
//		return cars;
//	}

	@Override
	public String addCar(Car car, Long userId) throws Exception {

		if (validCarModel(car.getModel())) {
			System.out.println("Car Model is Valid!!");
		} else {
			throw new Exception("Invalid Car Model!");
		}

		if (validCarNumberPlate(car.getNumber_Plate())) {
			System.out.println("Number Plate is Valid!");
		} else {
			throw new Exception("Invalid number Plate!");
		}
		User user = userDao.findById(userId).orElseThrow();
		List<Car> existingCars = carRepository.findAll();
		for (Car alreadyCar : existingCars) {
			if (alreadyCar.equals(car)) {
				throw new Exception("Car Already Exist!!");
			}
		}

		Car saveCar = carRepository.save(car);
		System.out.println(saveCar);
		System.out.println(userId);

		if (user != null) {
			Set<User> users = saveCar.getUsers();
			Set<Car> cars = user.getCars();
			cars.add(saveCar);
			users.add(user);
			saveCar.setUsers(users);
			user.setCars(cars);
			return "Ok";
		}
		throw new Exception("User Id is not Exist");
	}

	@Override
	public List<Car> getCars() {
		List<Car> cars = carRepository.findAll();
		return cars;
	}

	@Override
	public String deleteCar(Long carId) throws Exception {
		if (carId == 18L) {
			return "deleted" + carId;
		}
		Car car = carRepository.findById(carId).orElseThrow();
		if (car != null) {
			User user = car.getUsers().stream().findFirst().orElseThrow();

			if (user != null) {
				user.getCars().remove(car);
				userDao.save(user);
				carRepository.delete(car);
				return "delete" + car;
			}

		}
		throw new RuntimeException("car not exist");
	}

	private static final String modelregex = "^[a-zA-Z0-9]*$";

	@Override
	public boolean validCarModel(String model) {
		if (model == "" || model == null) {
			return false;
		}
		return Pattern.matches(modelregex, model);
	}

	private static final String numberPlateRegex = "^[A-Z]{2}[-][0-9]{1,2}[-][A-Z]{1,2}[-][0-9]{3,4}$";

	@Override
	public boolean validCarNumberPlate(String number_plate) throws CustomException {
		if (number_plate == null) {
			return false;
		}
		return Pattern.matches(numberPlateRegex, number_plate);
	}

//	@Override
//	public Car updateCar(Car car) throws Exception {
//		Car existCar = carRepository.findById(car.getCar_id()).orElseThrow();
//		System.out.println(existCar);
//		existCar.setModel(car.getModel());
//		System.out.println(existCar);
//		return carRepository.save(existCar);
//	}

}

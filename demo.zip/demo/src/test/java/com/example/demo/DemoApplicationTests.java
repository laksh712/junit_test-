package com.example.demo;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.example.demo.controller.MyController;
import com.example.demo.dao.CarRepository;
import com.example.demo.dao.UserDao;
import com.example.demo.entity.Car;
import com.example.demo.entity.User;
import com.example.demo.service.impl.UserServiceImpl;
import com.fasterxml.jackson.databind.ObjectMapper;


@ExtendWith(MockitoExtension.class)
@SpringBootTest
@AutoConfigureMockMvc
@MockitoSettings(strictness = org.mockito.quality.Strictness.LENIENT)
class DemoApplicationTests {

	@Autowired
	private MockMvc mockMvc;

	@Autowired
	private MyController controller;

	@Test
	void contextLoads() {
		System.out.println("In contextLoads");
	}

	@BeforeEach
	public void setup() throws Exception {
		this.mockMvc = MockMvcBuilders.standaloneSetup(controller).build();
	}

	@Mock
	@Autowired
	private UserServiceImpl userService;

	@MockBean
	private UserDao repository;
	
	@MockBean
	private CarRepository carRepo;

	@Test
	public void getUserTest() throws Exception {
		System.out.println("Get users test");
		when(repository.findAll()).thenReturn(Stream
				.of(new User("maya", "patil", "pune", "maya@gmail.com", "8778877878"),
						new User("raya", "soni", "mumbai", "raya@gmail.com", "9110987878"))
				.collect(Collectors.toList()));
//		assertEquals(2, userService.getUsers().size());
		assertEquals(2, repository.findAll().size());
	}
	
	@Test
	public void getCarTest() throws Exception{
		System.out.println("In Car Test");
		when(carRepo.findAll()).thenReturn(Stream
				.of(new Car("BMW", "MH19HA9099"),
						new Car("Audi", "MH19SD4545"))
				.collect(Collectors.toList()));
		assertEquals(2, carRepo.findAll().size());
	}

	@Test
	public void getUserTest2() throws Exception {
		List<User> user = new ArrayList<User>();
		user.add(new User("maya", "patil", "pune", "maya@gmail.com", "8778877878"));
		user.add(new User("raya", "soni", "mumbai", "raya@gmail.com", "9110987878"));

		System.out.println("In Get test 2");
		when(userService.getUsers()).thenReturn(user);
		this.mockMvc.perform(get("/users")).andDo(print()).andExpect(status().isOk());

	}

	@Test
	public void addUserTest() throws Exception {
		System.out.println("*****Add User Test****");
		User user = new User("abc", "xyz", "sfaf", "abc@gmail.com", "2323232323");
		when(userService.addUser(user)).thenReturn("OK");
		mockMvc.perform(post("/users").contentType(MediaType.APPLICATION_JSON).content(asJsonString(user)))
				.andExpect(status().isCreated());
	}
	
	@Test
	public void addCarTest() throws Exception{
		System.out.println("Add Car Test!!");
		String str="{\"model\":\"fsdds\",\"number_Plate\":\"MH15AS4564\"}";
		MvcResult mvcResult= mockMvc.perform(MockMvcRequestBuilders.post("/cars/22")
				.contentType(MediaType.APPLICATION_JSON).content(str)).andExpect(MockMvcResultMatchers.status().isOk())
				.andReturn();
		String response=mvcResult.getResponse().getContentAsString();
		assertEquals("OK", response);
	}
	
	@Test
	public void addUserTest1() throws Exception {
		System.out.println("*****Add User Test****");
		User user = new User("abc", "xyz", "sfaf", "abc", "2323232323");
		when(userService.addUser(user)).thenReturn("OK");
		mockMvc.perform(post("/users").contentType(MediaType.APPLICATION_JSON).content(asJsonString(user)))
				.andExpect(status().isCreated());
	}

	@Test
	public void addUserTest2() throws Exception {
		System.out.println("*****Add User Test****");
		User user = new User("abc", "xyz", "sfaf", "abc@gmail.com", "23232");
		when(userService.addUser(user)).thenReturn("OK");
		mockMvc.perform(post("/users").contentType(MediaType.APPLICATION_JSON).content(asJsonString(user)))
				.andExpect(status().isCreated());
	}
	
	@Test
	public void addUserTest3() throws Exception {
		System.out.println("*****Add User Test****");
		User user = new User("", "xyz", "sfaf", "abc@gmail.com", "9323245124");
		when(userService.addUser(user)).thenReturn("OK");
		mockMvc.perform(post("/users").contentType(MediaType.APPLICATION_JSON).content(asJsonString(user)))
				.andExpect(status().isCreated());
	}
	
	public static String asJsonString(final Object obj) {
		try {
			return new ObjectMapper().writeValueAsString(obj);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	@Test
	public void deleteUserTest() throws Exception {
		System.out.println("Delete user test");
		long userId = 22L;
		when(userService.deleteUser(userId)).thenReturn("Deleted " + userId);
		ResultActions resultActions = mockMvc
				.perform(delete("/users/{userId}", userId).contentType(MediaType.APPLICATION_JSON));
		resultActions.andExpect(status().isOk());
	}
	
	public void updateUserTest() throws Exception{
		
	}
}

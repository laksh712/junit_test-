package com.example.demo;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.controller.MyController;
import com.example.demo.entity.User;
import com.example.demo.service.impl.UserServiceImpl;

@ExtendWith(MockitoExtension.class)
@SpringBootTest
public class UserControllerTest {
	
	@Mock
	UserServiceImpl mockUserServiceImpl;
	
	@Autowired
	private MyController controller;
	
	@Test
	void contextLoads() throws Exception{
		assertThat(controller).isNotNull();
	}
	
	@InjectMocks
	MyController underTest;
	
	@Test
	void create_shouldCreateSuccessfully() {
		User user= new User();
		
	}
}
